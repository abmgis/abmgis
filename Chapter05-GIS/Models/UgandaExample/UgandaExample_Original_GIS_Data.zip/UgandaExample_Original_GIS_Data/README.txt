GIS data from World Pop and Natural Earth for the Uganda QGIS example.

http://www.worldpop.org.uk/data/

http://www.naturalearthdata.com/downloads/10m-physical-vectors/
