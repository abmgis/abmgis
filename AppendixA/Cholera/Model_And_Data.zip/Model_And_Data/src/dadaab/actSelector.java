/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dadaab;

/**
 *
 * @author gmu
 */
public class actSelector {
    
    private double timer =0;
    private double [] actWeight;
    private int freq;// how many times an activity can be performed per day
    private double priorWeighIndex; // priority
    
    
}
